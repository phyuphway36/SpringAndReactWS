package com.hostmdy.lawfirm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LawFirmApplicationTests {

	@Test
	void contextLoads() {
	}

}

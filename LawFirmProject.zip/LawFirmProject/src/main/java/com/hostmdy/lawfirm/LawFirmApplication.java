package com.hostmdy.lawfirm;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LawFirmApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(LawFirmApplication.class, args);
	}


		
		
	}



package com.hostmdy.lawfirm.repository;

import org.springframework.data.repository.CrudRepository;

import com.hostmdy.lawfirm.domain.Description;

public interface DescriptionRepository extends CrudRepository<Description, Long>{

}

package com.hostmdy.lawfirm.domain;

public enum Status {
	Agree, Disagree;
}

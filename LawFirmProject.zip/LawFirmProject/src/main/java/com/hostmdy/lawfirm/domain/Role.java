
package com.hostmdy.lawfirm.domain;

public enum Role {
	CLIENT,ADMIN,USER

}

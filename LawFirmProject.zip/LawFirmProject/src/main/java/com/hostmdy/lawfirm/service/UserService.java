package com.hostmdy.lawfirm.service;

public interface UserService {

}

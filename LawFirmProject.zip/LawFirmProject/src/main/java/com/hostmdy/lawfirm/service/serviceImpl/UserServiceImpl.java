package com.hostmdy.lawfirm.service.serviceImpl;

import org.springframework.stereotype.Service;

import com.hostmdy.lawfirm.service.UserService;

@Service
public class UserServiceImpl implements UserService{

}
